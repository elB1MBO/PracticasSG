 
var LIBS={
  toRad: function (angle) {
    return (angle*Math.PI/180.0);
  },
  
  toGrad: function (angle) {
    return (angle*180.0/Math.PI);
  }
};
